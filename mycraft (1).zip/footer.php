<div style="border: 0px solid; border-radius: 10px;" class="container">
 
<footer style="border: 0px solid; border-radius: 10px;" class="copyright">
<br>
<p class="text-center"><b>&copy <b><?php echo $ayarcek['sunucu_isim']; ?></b> - Tüm Hakları Saklıdır!</b></p>

<p style="font-size: 12px;" class="text-center"><a style="color: orange;" href="https://www.r10.net/members/111949-timberlock.html">TimberLock</a> ve <a style="color: orange;" href="https://www.mc-tr.com/uyeler/halilbuba.86888/">HalilTetik</a> tarafından <a style="color: orange;" href="https://mycraft.alwaysdata.net">MyCraft</a></p><br>
</footer> 
 
</div>